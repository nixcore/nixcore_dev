#!/bin/sh
. /usr/sbin/network.lib.sh
wifi_sta_connect $1 $2 $3 $4
