#!/bin/sh

# This script contains functions related to Nixcore operations.  Include
# this script in your scripts to access the same functions

nixtest ()
{
    echo "This is a test function"
}

# EOF
