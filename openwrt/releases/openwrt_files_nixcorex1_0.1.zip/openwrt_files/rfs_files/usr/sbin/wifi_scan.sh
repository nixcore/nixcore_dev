#!/bin/sh
. /usr/sbin/network.lib.sh
wifi_scan
