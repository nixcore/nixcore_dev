To prepare a release, edit the following files:

openwrt_files/etc/banner
openwrt_files/etc/nixcore_version
openwrt/version

