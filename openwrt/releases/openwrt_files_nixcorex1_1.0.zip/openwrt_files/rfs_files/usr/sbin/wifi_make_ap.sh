#!/bin/sh
. /usr/sbin/network.lib.sh
wifi_ap_create $1 $2 $3 $4
